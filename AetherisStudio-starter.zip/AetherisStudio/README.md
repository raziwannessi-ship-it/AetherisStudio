# Aetheris Studio

Native Android starter for a three-stem audio separation studio:
- Dialogue
- Music
- Sound Effects

## Build
Requires JDK 17 and Gradle 8.9+ (Android Gradle Plugin 8.7.3).
Run:

```bash
gradle :app:assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions builds a debug APK on pushes to `main` and on manual workflow dispatch.

## Current scope
This is the first buildable UI foundation. It includes the dark Compose interface and Android media picker. The actual TIGER-DnR inference, FFmpeg decoding, stem playback/mixing, and export pipeline are subsequent implementation tasks; the UI does not claim to separate audio yet.
