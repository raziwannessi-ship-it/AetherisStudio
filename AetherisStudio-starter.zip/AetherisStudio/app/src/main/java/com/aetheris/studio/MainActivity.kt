package com.aetheris.studio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Canvas = Color(0xFF090B12)
private val Panel = Color(0xFF141927)
private val Accent = Color(0xFF9B7BFF)
private val Muted = Color(0xFF929AAF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AetherisApp() }
    }
}

@Composable
private fun AetherisApp() {
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf("No audio or video selected") }
    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedUri = uri
            selectedName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected media"
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Canvas,
            surface = Panel,
            primary = Accent,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Canvas) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 22.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("AETHERIS", color = Color.White, fontSize = 13.sp, letterSpacing = 4.sp)
                        Text("STUDIO", color = Accent, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("v0.1.0", color = Muted, fontSize = 12.sp)
                }

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Audio, separated.", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("Isolate dialogue, music and sound effects.", color = Muted, fontSize = 14.sp)
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("NEW PROJECT", color = Accent, fontSize = 11.sp, letterSpacing = 2.sp)
                        Text(selectedName, color = Color.White, fontSize = 14.sp)
                        Button(
                            onClick = { picker.launch(arrayOf("audio/*", "video/mp4", "video/*")) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("Import audio or video") }
                        Text("MP4 · MP3 · WAV · M4A", color = Muted, fontSize = 11.sp)
                    }
                }

                Text("SEPARATION STEMS", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                StemCard("01", "Dialogue", "Voice and spoken words", "VOICE")
                StemCard("02", "Music", "Instrumental and musical bed", "MUSIC")
                StemCard("03", "Sound Effects", "Ambience and effects", "SFX")

                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("PROCESSING ENGINE", color = Accent, fontSize = 11.sp, letterSpacing = 1.5.sp)
                        Text("Separation engine is the next integration step.", color = Color.White, fontSize = 14.sp)
                        Text("Your imported file is selected locally. No upload is performed by this starter build.", color = Muted, fontSize = 12.sp)
                    }
                }
                Text("AETHERIS STUDIO  •  BUILT FOR ANDROID", color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
            }
        }
    }
}

@Composable
private fun StemCard(number: String, title: String, description: String, tag: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(number, color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(description, color = Muted, fontSize = 12.sp)
            }
            Text(tag, color = Accent, fontSize = 10.sp, letterSpacing = 1.sp)
        }
    }
}
